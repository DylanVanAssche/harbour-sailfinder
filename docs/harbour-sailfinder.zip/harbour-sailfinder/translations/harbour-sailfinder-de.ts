<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>AboutPage</name>
    <message>
        <location filename="../qml/pages/AboutPage.qml" line="50"/>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorPage</name>
    <message>
        <location filename="../qml/pages/ErrorPage.qml" line="18"/>
        <source>ERROR!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/ErrorPage.qml" line="21"/>
        <source>Report this error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/ErrorPage.qml" line="31"/>
        <source>The error has been copied to your clipboard, please report it on Github or on Openrepos.net (Github is preferred).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/ErrorPage.qml" line="50"/>
        <source>Sailfinder bug tracker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/ErrorPage.qml" line="59"/>
        <source>Sailfinder on Openrepos.net</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FirstPage</name>
    <message>
        <location filename="../qml/pages/FirstPage.qml" line="16"/>
        <location filename="../qml/pages/FirstPage.qml" line="134"/>
        <source>Logging in...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/FirstPage.qml" line="26"/>
        <source>Retry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/FirstPage.qml" line="81"/>
        <source>Login with Facebook</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/FirstPage.qml" line="120"/>
        <location filename="../qml/pages/FirstPage.qml" line="155"/>
        <source>Logging into Tinder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/FirstPage.qml" line="121"/>
        <location filename="../qml/pages/FirstPage.qml" line="156"/>
        <source>Validating credentials...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/FirstPage.qml" line="181"/>
        <source>Failed to login :-(</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/FirstPage.qml" line="182"/>
        <source>Tinder login token expired!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GalleryPage</name>
    <message>
        <location filename="../qml/pages/GalleryPage.qml" line="19"/>
        <source>Facebook albums</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/GalleryPage.qml" line="25"/>
        <location filename="../qml/pages/GalleryPage.qml" line="42"/>
        <source>Facebook login expired :-(</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/GalleryPage.qml" line="26"/>
        <location filename="../qml/pages/GalleryPage.qml" line="43"/>
        <source>Relogin into Facebook</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/GalleryPage.qml" line="73"/>
        <source>Gallery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/GalleryPage.qml" line="74"/>
        <source>Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/GalleryPage.qml" line="246"/>
        <source>Relogin with Facebook</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/GalleryPage.qml" line="250"/>
        <source>Restart Sailfinder now</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainPage</name>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="104"/>
        <location filename="../qml/pages/MainPage.qml" line="759"/>
        <location filename="../qml/pages/MainPage.qml" line="770"/>
        <source>Searching for people</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="105"/>
        <location filename="../qml/pages/MainPage.qml" line="760"/>
        <location filename="../qml/pages/MainPage.qml" line="771"/>
        <source>A moment please...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="112"/>
        <location filename="../qml/pages/MainPage.qml" line="773"/>
        <location filename="../qml/pages/MainPage.qml" line="829"/>
        <source>Loading new people...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="25"/>
        <location filename="../qml/pages/MainPage.qml" line="267"/>
        <source>Out of likes!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="107"/>
        <source>Searching...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="278"/>
        <source>API ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="279"/>
        <source>Reloading in 5 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="332"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="341"/>
        <source>Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="350"/>
        <source>People</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="512"/>
        <source>School</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="553"/>
        <source>Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="606"/>
        <source>Instagram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="689"/>
        <source>Matched with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="732"/>
        <source>Open People</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="742"/>
        <source>Swipe further</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="821"/>
        <source>No new users in the area :-(</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="822"/>
        <source>Extend your search criteria...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="839"/>
        <source>Tinder login expired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MainPage.qml" line="840"/>
        <source>Reauthenticating in 5 seconds...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessagingPage</name>
    <message>
        <location filename="../qml/pages/MessagingPage.qml" line="23"/>
        <source>Last seen: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MessagingPage.qml" line="238"/>
        <location filename="../qml/pages/MessagingPage.qml" line="271"/>
        <source>Hi </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MessagingPage.qml" line="238"/>
        <location filename="../qml/pages/MessagingPage.qml" line="260"/>
        <location filename="../qml/pages/MessagingPage.qml" line="271"/>
        <source>!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MessagingPage.qml" line="115"/>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MessagingPage.qml" line="126"/>
        <source>last seen: N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MessagingPage.qml" line="247"/>
        <source>Message send!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MessagingPage.qml" line="259"/>
        <source>No messages :(</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/MessagingPage.qml" line="260"/>
        <source>Say hi to </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeoplePage</name>
    <message>
        <location filename="../qml/pages/PeoplePage.qml" line="14"/>
        <location filename="../qml/pages/PeoplePage.qml" line="82"/>
        <source> matches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/PeoplePage.qml" line="18"/>
        <source> match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/PeoplePage.qml" line="103"/>
        <source>People</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/PeoplePage.qml" line="220"/>
        <source>Refreshing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/PeoplePage.qml" line="242"/>
        <source>Loading matches...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/PeoplePage.qml" line="221"/>
        <location filename="../qml/pages/PeoplePage.qml" line="243"/>
        <source>A moment please</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProfilePage</name>
    <message>
        <location filename="../qml/pages/ProfilePage.qml" line="86"/>
        <source>&apos;s profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/ProfilePage.qml" line="108"/>
        <location filename="../qml/pages/ProfilePage.qml" line="112"/>
        <location filename="../qml/pages/ProfilePage.qml" line="127"/>
        <source>Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/ProfilePage.qml" line="132"/>
        <source>Update profile</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SailfinderPage</name>
    <message>
        <location filename="../qml/pages/SailfinderPage.qml" line="17"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="13"/>
        <location filename="../qml/pages/SettingsPage.qml" line="35"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="43"/>
        <source>Show bio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="50"/>
        <source>Show school</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="57"/>
        <source>Show job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="64"/>
        <source>Show Instagram account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="74"/>
        <source>Latitude: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="82"/>
        <source>Longitude: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="89"/>
        <source>Waiting for GPS signal...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SettingsPage.qml" line="155"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpdateProfilePage</name>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="133"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="134"/>
        <source>Update profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="137"/>
        <source>Photos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="114"/>
        <source>Facebook</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="115"/>
        <source>Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="116"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="150"/>
        <source>Upload a new picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="159"/>
        <source>Select a picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="318"/>
        <source>Bio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="324"/>
        <source>Type your bio here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="341"/>
        <source>Gender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="349"/>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="477"/>
        <source>Male</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="350"/>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="478"/>
        <source>Female</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="354"/>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="364"/>
        <source>Tinder username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="365"/>
        <source>Share your profile now!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="377"/>
        <source>Get share URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="416"/>
        <source>My share URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="454"/>
        <source>Username succesfully deleted!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="476"/>
        <source>Everyone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="575"/>
        <source>Username already in use!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="581"/>
        <source>Username created!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="586"/>
        <source>Username changed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="591"/>
        <source>Username deleted!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="25"/>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="26"/>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="154"/>
        <source>Delete this picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="325"/>
        <source>Your bio (max 500 characters)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="425"/>
        <source>Share text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="432"/>
        <source>Delete username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="457"/>
        <source>Discoverable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="462"/>
        <source>Discovery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="463"/>
        <source>Choose if other people can see your Tinder profile or not. This has no effect on your matches you already have. When disabled, you can&apos;t change your search criteria.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="467"/>
        <source>Search criteria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="472"/>
        <source>Interested in: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="490"/>
        <source>Minimum age</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="509"/>
        <source>Maximum age</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="528"/>
        <source>Search distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/UpdateProfilePage.qml" line="542"/>
        <source>Enable discovery to change the search criteria.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>helper</name>
    <message>
        <location filename="../qml/pages/lib/helper.js" line="62"/>
        <source> days ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/lib/helper.js" line="66"/>
        <source> day ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/lib/helper.js" line="76"/>
        <source> hours ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/lib/helper.js" line="80"/>
        <source> hour ago</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
