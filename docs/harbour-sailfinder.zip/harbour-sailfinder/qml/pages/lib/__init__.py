# -*- coding: utf-8 -*-
"""
Created on Sat Aug  6 10:52:34 2016

@author: Dylan Van Assche
@title: Init lib module for Sailfinder
"""

